/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.matersys.escuelaapp.util;

/**
 *
 * @author eiste
 */
public interface TipoUsuario {
    String PADRE = "1";
    String PROFESOR = "2";
    String ADMINISTRATIVO = "3";
}
