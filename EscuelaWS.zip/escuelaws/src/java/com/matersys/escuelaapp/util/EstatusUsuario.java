/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.matersys.escuelaapp.util;

/**
 *
 * @author eiste
 */
public interface EstatusUsuario {
    String ACTIVO = "1";
    String INACTIVO = "2";
    String BAJA = "3";
}
