/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.matersys.escuelaapp.util;

/**
 *
 * @author eiste
 */
public interface EscuelaAppWSClass {
    String ALUMNOWS_CLASS = "class com.matersys.escuelaapp.ws.AlumnoWS";
    String APPPROFESORWS_CLASS = "class com.matersys.escuelaapp.ws.AppProfesorWS";
    String ASIGNACIONESPROFESWS_CLASS = "class com.matersys.escuelaapp.ws.AsignacionesProfesWS";
    String ASIGNATURAWS_CLASS = "class com.matersys.escuelaapp.ws.AsignaturaWS";
    String CICLOESCOLARWS_CLASS = "class com.matersys.escuelaapp.ws.CicloEscolarWS";
    String GENERALWS_CLASS = "class com.matersys.escuelaapp.ws.UsuarioWS";
    String GRUPOWS_CLASS = "class com.matersys.escuelaapp.ws.GrupoWS";
    String PADRETUTORWS_CLASS = "class com.matersys.escuelaapp.ws.PadretutorWS";
    String PROFESORWS_CLASS = "class com.matersys.escuelaapp.ws.ProfesorWS";
    String USUARIOWS_CLASS = "class com.matersys.escuelaapp.ws.UsuarioWS";
    String APPPADRETUTORWS_CLASS = "class com.matersys.escuelaapp.ws.AppPadreTutorWS";
}
