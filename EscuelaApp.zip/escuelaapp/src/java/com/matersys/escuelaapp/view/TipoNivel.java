/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.matersys.escuelaapp.view;

/**
 *
 * @author Alejandro Elias
 */
public interface TipoNivel {
    String PRESCOLAR = "1";
    String PRIMARIA = "2";
    
    
}
