/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.matersys.escuelaapp.web.action;

import com.matersys.escuelaapp.web.form.BandejaGruposForm;
import com.matersys.escuelaapp.web.form.BandejaNivelForm;
import com.matersys.escuelaapp.ws.client.grupo.Admin_002fGrupoWS;
import com.matersys.escuelaapp.ws.client.grupo.GrupoDTO;
import com.matersys.escuelaapp.ws.client.grupo.GrupoWS;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionErrors;

import org.apache.struts.actions.DispatchAction;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMessage;

/**
 *
 * @author Alejandro Elias
 */
public class BandejaNivelAction extends EscuelaAppAction {

    private static final String PREESCOLAR = "Preescolar"; 
     public ActionForward inicio(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        if (notIsSessionValid(request)) {
            return super.logout(mapping, form, request, response);
        }
        BandejaNivelForm bnform = (BandejaNivelForm) form;
        String forward = request.getParameter("method");
        ActionErrors errors = new ActionErrors();
        try {
            Admin_002fGrupoWS gwss = new Admin_002fGrupoWS();
            GrupoWS gws = gwss.getGrupoWSPort();
            List<GrupoDTO> grupos = gws.consultarGrupos(getUsuario(request).getAdministrativoDTO().getEscuela());
            List<String> listanivel = new ArrayList<>();
            boolean bandera = false;
            bgform.setBandeja(grupos);
            List<GrupoDTO >gdto2= grupos;
            gdto2.get(1).
            for(GrupoDTO gdto: grupos ){
            }
                
                System.out.println();
                
            }
            
           
        } catch (Exception e) {
            System.out.println("Exception e [" + e.getMessage() + "]");
            errors.add("failure", new ActionMessage("error.system.failure"));
        }
        saveErrors(request, errors);
        return mapping.findForward(forward);
    }

}
