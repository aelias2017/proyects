/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.matersys.escuelaapp.web.form;

import com.matersys.escuelaapp.ws.client.grupo.GrupoDTO;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 *
 * @author Alejandro Elias
 */
public class BandejaNivelForm extends org.apache.struts.action.ActionForm {
    
    private String method;
    private int indice;
    private List<GrupoDTO> bandeja;
    private GrupoDTO gdetalle;
    
    public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        if (getMethod()== null || getMethod().length() < 1) {
            errors.add("name", new ActionMessage("error.name.required"));
            // TODO: add 'error.name.required' key to your resources
        }
        return errors;
    }

    /**
     * @return the method
     */
    public String getMethod() {
        return method;
    }

    /**
     * @param method the method to set
     */
    public void setMethod(String method) {
        this.method = method;
    }

    /**
     * @return the indice
     */
    public int getIndice() {
        return indice;
    }

    /**
     * @param indice the indice to set
     */
    public void setIndice(int indice) {
        this.indice = indice;
    }

    /**
     * @return the bandeja
     */
    public List<GrupoDTO> getBandeja() {
        return bandeja;
    }

    /**
     * @param bandeja the bandeja to set
     */
    public void setBandeja(List<GrupoDTO> bandeja) {
        this.bandeja = bandeja;
    }

    /**
     * @return the gdetalle
     */
    public GrupoDTO getGdetalle() {
        return gdetalle;
    }

    /**
     * @param gdetalle the gdetalle to set
     */
    public void setGdetalle(GrupoDTO gdetalle) {
        this.gdetalle = gdetalle;
    }
}
