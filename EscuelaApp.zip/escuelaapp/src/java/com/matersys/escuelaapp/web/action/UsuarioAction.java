/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.matersys.escuelaapp.web.action;

import com.matersys.escuelaapp.view.EscuelaAppSession;
import com.matersys.escuelaapp.view.TipoUsuario;
import com.matersys.escuelaapp.web.form.UsuarioForm;
import com.matersys.escuelaapp.ws.client.general.GeneralWS;
import com.matersys.escuelaapp.ws.client.general.GeneralWS_Service;
import com.matersys.escuelaapp.ws.client.general.UsuarioDTO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 *
 * @author eiste
 */
public class UsuarioAction extends org.apache.struts.action.Action {

    /* forward name="success" path="" */
    private static final String SUCCESS = "success";
    private static final String FAILURE = "failure";

    /**
     * This is the action called from the Struts framework.
     *
     * @param mapping The ActionMapping used to select this instance.
     * @param form The optional ActionForm bean for this request.
     * @param request The HTTP Request we are processing.
     * @param response The HTTP Response we are processing.
     * @throws java.lang.Exception
     * @return
     */
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        UsuarioForm usuarioForm = (UsuarioForm) form;
        ActionErrors errors = new ActionErrors();
        String forward = FAILURE;
        try {
            String usuarioid = usuarioForm.getUsername().trim();
            String password = usuarioForm.getPassword().trim();
            GeneralWS_Service gwss = new GeneralWS_Service();
            GeneralWS gws = gwss.getGeneralWSPort();
            boolean autentica = gws.autentica(usuarioid, password);
            System.out.println("autentica " + usuarioid + " [" + autentica + "]");
            if (autentica) {
                UsuarioDTO usuario = gws.obtenerUsuario(usuarioid, password);
                if (!usuario.getTipo().equals(TipoUsuario.ADMINISTRATIVO)) {
                    errors.add("failure", new ActionMessage("error.permiso.denegado"));
                } else {
                    usuario.setPassword(password);
                    request.getSession(true).setAttribute(EscuelaAppSession.USUARIO, usuario);
                    forward = SUCCESS;
                }
            } else {
                errors.add("failure", new ActionMessage("error.autentica.failure"));
            }
        } catch (Exception e) {
            System.out.println("Exception [" + e.getMessage() + "]");
            errors.add("failure", new ActionMessage("error.system.failure"));
        }
        saveErrors(request, errors);
        return mapping.findForward(forward);
    }
}
