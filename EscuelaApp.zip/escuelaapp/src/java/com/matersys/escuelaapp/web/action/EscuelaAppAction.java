/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.matersys.escuelaapp.web.action;

import com.matersys.escuelaapp.view.EscuelaAppSession;
import com.matersys.escuelaapp.ws.client.general.UsuarioDTO;
import java.util.Enumeration;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.actions.DispatchAction;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

/**
 *
 * @author eiste
 */
public class EscuelaAppAction extends DispatchAction {

    /**
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws java.lang.Exception
     */
    public ActionForward logout(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        System.out.println("Sesión inválida");
        return mapping.findForward(EscuelaAppSession.TIMEOVER);
    }

    protected boolean notIsSessionValid(HttpServletRequest request) {
        HttpSession session = request.getSession();
        return session == null || getUsuario(request) == null;
    }

    protected UsuarioDTO getUsuario(HttpServletRequest request) {
        return (UsuarioDTO) request.getSession().getAttribute(EscuelaAppSession.USUARIO);
    }

    protected void printSessionObjects(HttpServletRequest request) {
        Object obj;
        Enumeration req_attrib = request.getAttributeNames();
        System.out.println("Attrib Request:");
        while (req_attrib.hasMoreElements()) {
            obj = req_attrib.nextElement();
            System.out.println(obj.toString());
        }

        Enumeration ses_attrib = request.getSession().getAttributeNames();
        System.out.println("Attrib Session:");
        while (ses_attrib.hasMoreElements()) {
            obj = ses_attrib.nextElement();
            System.out.println(obj.toString());
        }
    }
    
    protected void cleaningSession(HttpServletRequest request, String form) {
        HttpSession session = request.getSession();
        Enumeration ses_attrib = request.getSession().getAttributeNames();
        String obj;
        while (ses_attrib.hasMoreElements()) {
            obj = ses_attrib.nextElement().toString();
            if(!obj.equals(EscuelaAppSession.USUARIO) && !obj.equals(form)){
                session.removeAttribute(obj);
            }
        }
    }
}
